# Main-menu assets

Lege das fertige Hintergrundbild hier als `main_menu_background.png` ab.

Die Szene lädt es zur Laufzeit und fällt bei einer fehlenden Datei sicher auf den Placeholder zurück.
